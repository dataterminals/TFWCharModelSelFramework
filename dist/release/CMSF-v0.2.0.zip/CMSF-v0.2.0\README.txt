﻿CMSF v0.2.0 -- Character Model Selection Framework
====================================================

Adds new character skins to the select screen instead of overwriting the ones the
game ships with. It also unlocks the base skins the game already has but never
lets you pick, which is worth having even with no skin mods installed.

INSTALLING

  Copy the "Windows" folder from this archive into your game folder, so it merges
  with the one already there:

      ...\steamapps\common\The Forever Winter\

  That puts two things in place:

      Windows\ForeverWinter\Content\Paks\Mods\        the framework pak
      Windows\...\Binaries\Win64\ue4ss\Mods\CMSFUnlock\   the runtime

  The Mods\ folder may not exist yet -- copying the Windows folder in creates it.

  Launch, pick a character, open the skin menu.

  MOD ORGANIZER 2 USERS: do not copy anything into the game folder. Install this
  archive as an ordinary MO2 mod instead. MO2 virtualises both of those
  directories, so files copied in by hand are not what the game sees.

REQUIREMENTS

  UE4SS            tested against 3.0.1-894. You likely have it already.
  Signature Bypass required for any content pak mod, not just this one.

ADDING SKINS

  A CMSF skin is an ordinary pak you drop in the same Mods\ folder. Skin paks
  MUST load after the framework -- their filenames already carry the right
  load-order token, so do not rename them.

  Mod Organizer 2: MO2 priority decides load order and overrides the filename,
  so put skins ABOVE the framework in the left pane.

NOT BUGS

  * A skin can be missing for about a second when the menu first opens, then
    appear. The game reuses tile widgets across panels, so the first pass reads a
    stale image. It corrects itself.
  * Empty slots do not show. The framework provisions many; you only ever see
    ones a skin actually claimed.

IF A SKIN YOU INSTALLED IS NOT SHOWING

  Almost always load order -- the skin pak has to load AFTER the framework. Open
  the console and type  cmsfnoprune  to show every slot including empty ones. If
  yours reads "CMSF SLOT NN UNCLAIMED", the pak is not loading, or is loading
  before the framework.

UNINSTALLING

  Delete the files. If you were wearing a CMSF skin the game rolls you onto a
  normal one next time you die. Nothing to repair.

CMSF is MIT licensed. Built with UE4SS (https://github.com/UE4SS-RE/RE-UE4SS).
